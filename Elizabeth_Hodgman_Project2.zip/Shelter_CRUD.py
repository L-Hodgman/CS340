#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 17 20:45:08 2022

@author: elizabethhodg_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:41069/?authSource=AAC' % (username, password))
        # Database is the "AAC"
        self.database = self.client['AAC']

# Method to implement the C in CRUD - Create data and insert into database.
    def create(self, data):
        if data is not None:
           inserted = self.database.animals.insert(data) # Insert new document
           if inserted != 0: # Return "True" if more than 0 documents were inserted
               return True        
           else: # Return "False" if 0 documents were inserted
               return False      
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Method to implement the R in CRUD - Read data from database. 
    def read(self, search = None):  
        if search is not None: # Finds specific data when search is inputted
            data = self.database.animals.find(search,{"_id": False})            
        else: # Finds all documents when search is not inputted
            data = self.database.animals.find({},{"_id": False})        
        return data
    
# Method to implement the U in CRUD - Update data from database.
    def update(self, initData, updateData):
        if initData is not None: # Initial data input is found - update docs with updated data        
            if self.database.animals.count_documents(initData, limit = 1) != 0:
                update_result = self.database.animals.update_many(initData, {"$set": updateData})
                result = update_result.raw_result                
            else: # Initial data input does not match any documents
                result = "No document was found"                
            return result        
        else:
            raise Exception("Nothing to update, because data parameter is empty")

# Method to implement the D in CRUD - Delete data from database.
    def delete(self, removeData):
        if removeData is not None: # Remove data input is found - remove all matching documents
            if self.database.animals.count_documents(removeData, limit = 1) != 0:
                delete_result = self.database.animals.delete_many(removeData)
                result = delete_result.raw_result                
            else: # Remove data does not match any documents
                result = "No document was found"                
            return result        
        else:
            raise Exception("Nothing to delete, because data parameter is empty")

